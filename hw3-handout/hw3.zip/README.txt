----- Prerequistes -----

The requirements.txt is in this src folder and you will need to input the command:

pip install requirements.txt

The code was run in an enviroment for Python 3.6.7

----- About ------
This project implements PageRank.

------ How to Run -------
You will need to run these commands in the terminal.

chmod +x hw3.sh

./hw3.sh

-----Files-------

main.py is the only file for this assignment.

----- Output -------

The output will be a few .txt files of outputs and the command line will show the timing of each method. 